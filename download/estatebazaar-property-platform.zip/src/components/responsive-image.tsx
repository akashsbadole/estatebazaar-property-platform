'use client'

import Image, { ImageProps } from 'next/image'
import { getImageVariants } from '@/lib/image-utils'

// ResponsiveImage wraps next/image and picks the best WebP variant
// from the optimized uploads (thumb/medium/large).
//
// For external URLs (Unsplash, etc.), it falls back to the original URL.

interface ResponsiveImageProps extends Omit<ImageProps, 'src'> {
  src: string
}

export function ResponsiveImage({ src, alt, sizes, className, fill, ...rest }: ResponsiveImageProps) {
  // Get all variant URLs from the stored URL
  const variants = getImageVariants(src)

  // Pick the best variant:
  // - For card thumbnails (fill, small), use medium (800px) — good balance
  // - For detail page (large), use large (1200px)
  // The browser + CDN will handle actual delivery
  const bestUrl = variants.medium || src

  return (
    <Image
      src={bestUrl}
      alt={alt || ''}
      fill={fill}
      sizes={sizes || '(max-width: 768px) 100vw, 33vw'}
      className={className}
      unoptimized
      {...rest}
    />
  )
}
